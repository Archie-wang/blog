title: 从github下载文件的一些方法
author: Archie
date: 2020-10-22 14:24:33
tags:
---
title:从github下载文件的一些方法  
date:2020-10-22  
tags:download,github  
catagories:tips 

_____



从github上下载文件主要涉及下载一整个项目、项目中的单个或多个文件夹或者是文件夹中的一个或多个文本，以下介绍的是下载单个文件夹或单个文本的一些操作方法。

一、下载单个文件夹

1、使用Tortoissvm软件，下载好软件后，进入到github中需要下载的文件夹的网址，如果是master分支，则将 **/tree/master/** 换成 **/trunk/**，develop分支，则将 **/trunk/** 换成 **/branches/branchname/**，也就是/branches/develop/

2、建立一个文件夹，右键使用svm checkout，将网址复制下载即可

二、单个文本下载

进入github，在右上角直接将文本另存为即可

