title: Machine Learning-KNN算法
author: Archie
date: 2020-10-20 23:36:43
tags:
---
title:Machine Learning -KNN算法
date:2020-10-20
tags:Machine Learning
catagories:Machine Learning        

---------------------------------------
#### 概述

​    KNN算法是通过计算新数据与训练集中数据的距离，根据距离最接近的前k个数据分布，来进行分类的。

​	本节主要概述KNN邻近算法的Python实现，以及算法总结和场景变换思考，详细资料参考[机器学习实战](https://cuijiahua.com/blog/2017/11/ml_1_knn.html)

#### 一、KNN算法的实现流程   

1）采集数据  

​		使用统计或者爬虫获取数据原生资料
2）处理数据

​		通常把数据处理成矩阵、向量，建立训练集，用于Python计算    
3）分析数据（数据可视化） 

​		使用Python的画图模块，绘制可视化图像，如散点图，进行可视化话直观分析

4）测试算法

​		随机选取数据的10%数据作为测试集，求算法的loss值

5）使用算法   

​		将算法应用到具体场景中

#### 二、Python实现   

##### 1、处理数据，建立训练集

```
def creatDateSet():
    #四组二维特征数组
    group = np.array([[1,101],[5,89],[108,5],[115,8]])
    #四组特征标签
    labels = ['爱情片','爱情片','动作片','动作片']
    return group,labels
#if ____name_____== '____main__' 下的代码只在本模块使用，移植到其他模块不会生效，常用于Print测试
if __name__ == '__main__':
    #创建数据集
    group,labels = creatDateSet()
    #打印数据集
    print(group)
    print(labels)
    
```

建立将数据和标签一一对应起来

##### 2、定义距离算法和分类器

```
import numpy as np
import operator
"""
函数说明：KNN算法，分类器
Parameters:
    inX-用于分类的数据
    dataSet-训练集
    lables-分类标签
    k-距离最近的k个点
Return:
    sortedClassCount[0][0]-分类结果
"""

def classify0(inX,dateSet,lables,k):
    #读取dateSet的矩阵行数
    dateSetSize = dateSet.shape[0]
    #重复inX形成dateSetSize行,1列的矩阵，并与dateSet相减
    diffMat = np.tile(inX,(dateSetSize,1))-dateSet
    #将所得数平方
    sqDiffMat = diffMat**2
    #行相加sum(axis =1)
    sqDistance = sqDiffMat.sum(axis =1)
    #开方，计算距离
    distance = sqDistance**0.5
    #返回distance从小到大排序后的索引值
    sortedDistIndices = distance.argsort()
    #定一个记录类别次数的字典
    classCount = {}
    for i in range(k):
        #取出前k个数据的分类标签
        voteILabel = labels[sortedDistIndices[i]]
        #计算类别次数
        classCount[voteILabel] = classCount.get(voteILabel,0)+1
        #对次数降序排序
    sortedClassCount = sorted(classCount.items(),key = operator.itemgetter(1),reverse=True)
    return sortedClassCount[0][0] 
    
```

说明：计算多维的距离用多维的欧式公式

![image-20201021151348740](C:\Users\Administrator\AppData\Roaming\Typora\typora-user-images\image-20201021151348740.png)



##### Python知识点：

1）shape用于获取数组的维度，shape[0]行，shape[1]列，二维或高维则返回依次由高维返回对应的维度tile

2）np.tile用于复制形成新的矩阵，np.tile(inX,(dateSetSize,1))dateSetSize行,1列的矩阵，其他高维矩阵同理

3）sum(axis =1)表示行相加，sum(axis =0)表示列相加

4）argsort()是倒序排列

5）字典的get一般用于在统计中建立新字典，classCount.get(voteILabel,0)，字典中有voteILabel返回默认值0，无则建立新的key

6）sort一般用于数字排列，sorted可用于迭代的数据类型排序，比如字典，sorted(classCount.items(),key = operator.itemgetter(1),reverse=True)，第一个参数是要排序的对象，第二个是排序的依据，operator.itemgetter(1)按值排序，0的话按key排序，第三个是排序顺序，默认从小到大，一般排序默认都是从小到大

#### 三、约会案例实战

##### 1、数据处理

```
import numpy as np
"""
函数说明:打开并解析文件，对数据进行分类：1代表不喜欢,2代表魅力一般,3代表极具魅力
 
Parameters:
    filename - 文件名
Returns:
    returnMat - 特征矩阵
    classLabelVector - 分类Label向量
 
Modify:
    2017-03-24
"""
def file2matrix(filename):
    #打开文件
    fr = open(filename)
    #读取文件所有内容
    arrayOLines = fr.readlines()
    #得到文件行数
    numberOfLines = len(arrayOLines)
    #返回的NumPy矩阵,解析完成的数据:numberOfLines行,3列
    returnMat = np.zeros((numberOfLines,3))
    #返回的分类标签向量
    classLabelVector = []
    #行的索引值
    index = 0
    for line in arrayOLines:
        #s.strip(rm)，当rm空时,默认删除空白符(包括'\n','\r','\t',' ')
        line = line.strip()
        #使用s.split(str="",num=string,cout(str))将字符串根据'\t'分隔符进行切片。
        listFromLine = line.split('\t')
        #将数据前三列提取出来,存放到returnMat的NumPy矩阵中,也就是特征矩阵
        returnMat[index,:] = listFromLine[0:3]
        #根据文本中标记的喜欢的程度进行分类,1代表不喜欢,2代表魅力一般,3代表极具魅力
        if listFromLine[-1] == 'didntLike':
            classLabelVector.append(1)
        elif listFromLine[-1] == 'smallDoses':
            classLabelVector.append(2)
        elif listFromLine[-1] == 'largeDoses':
            classLabelVector.append(3)
        index += 1
    return returnMat, classLabelVector
 
"""
函数说明:main函数
 
Parameters:
    无
Returns:
    无
 
Modify:
    2017-03-24
"""
if __name__ == '__main__':
    #打开的文件名
    filename = "datingTestSet.txt"
    #打开并处理数据
    datingDataMat, datingLabels = file2matrix(filename)
    print(datingDataMat)
    print(datingLabels)
```

##### Python知识点：

1）在进行数据切片前要进行数据清洗，strip，数据切片用split()根据特征切片

2）装入特征函数时[ a:b ,c:d]第一个参数是最高维度的行列，维度依次递减，根据改变a,b,c,d的值来截取不同的数据，切片后数据会装在list里面

##### 2、数据可视化分析（绘制散点图）

```
"""
函数说明:可视化数据
 
Parameters:
    datingDataMat - 特征矩阵
    datingLabels - 分类Label
Returns:
    无
Modify:
    2017-03-24
"""
def showdatas(datingDataMat, datingLabels):
    #设置汉字格式
    font = FontProperties(fname=r"c:\windows\fonts\simsun.ttc", size=14)
    #将fig画布分隔成1行1列,不共享x轴和y轴,fig画布的大小为(13,8)
    #当nrow=2,nclos=2时,代表fig画布被分为四个区域,axs[0][0]表示第一行第一个区域
    fig, axs = plt.subplots(nrows=2, ncols=2,sharex=False, sharey=False, figsize=(13,8))
 
    numberOfLabels = len(datingLabels)
    LabelsColors = []
    for i in datingLabels:
        if i == 1:
            LabelsColors.append('black')
        if i == 2:
            LabelsColors.append('orange')
        if i == 3:
            LabelsColors.append('red')
    #画出散点图,以datingDataMat矩阵的第一(飞行常客例程)、第二列(玩游戏)数据画散点数据,散点大小为15,透明度为0.5
    axs[0][0].scatter(x=datingDataMat[:,0], y=datingDataMat[:,1], color=LabelsColors,s=15, alpha=.5)
    #设置标题,x轴label,y轴label
    axs0_title_text = axs[0][0].set_title(u'每年获得的飞行常客里程数与玩视频游戏所消耗时间占比',FontProperties=font)
    axs0_xlabel_text = axs[0][0].set_xlabel(u'每年获得的飞行常客里程数',FontProperties=font)
    axs0_ylabel_text = axs[0][0].set_ylabel(u'玩视频游戏所消耗时间占',FontProperties=font)
    plt.setp(axs0_title_text, size=9, weight='bold', color='red') 
    plt.setp(axs0_xlabel_text, size=7, weight='bold', color='black') 
    plt.setp(axs0_ylabel_text, size=7, weight='bold', color='black')
 
    #画出散点图,以datingDataMat矩阵的第一(飞行常客例程)、第三列(冰激凌)数据画散点数据,散点大小为15,透明度为0.5
    axs[0][1].scatter(x=datingDataMat[:,0], y=datingDataMat[:,2], color=LabelsColors,s=15, alpha=.5)
    #设置标题,x轴label,y轴label
    axs1_title_text = axs[0][1].set_title(u'每年获得的飞行常客里程数与每周消费的冰激淋公升数',FontProperties=font)
    axs1_xlabel_text = axs[0][1].set_xlabel(u'每年获得的飞行常客里程数',FontProperties=font)
    axs1_ylabel_text = axs[0][1].set_ylabel(u'每周消费的冰激淋公升数',FontProperties=font)
    plt.setp(axs1_title_text, size=9, weight='bold', color='red') 
    plt.setp(axs1_xlabel_text, size=7, weight='bold', color='black') 
    plt.setp(axs1_ylabel_text, size=7, weight='bold', color='black')
 
    #画出散点图,以datingDataMat矩阵的第二(玩游戏)、第三列(冰激凌)数据画散点数据,散点大小为15,透明度为0.5
    axs[1][0].scatter(x=datingDataMat[:,1], y=datingDataMat[:,2], color=LabelsColors,s=15, alpha=.5)
    #设置标题,x轴label,y轴label
    axs2_title_text = axs[1][0].set_title(u'玩视频游戏所消耗时间占比与每周消费的冰激淋公升数',FontProperties=font)
    axs2_xlabel_text = axs[1][0].set_xlabel(u'玩视频游戏所消耗时间占比',FontProperties=font)
    axs2_ylabel_text = axs[1][0].set_ylabel(u'每周消费的冰激淋公升数',FontProperties=font)
    plt.setp(axs2_title_text, size=9, weight='bold', color='red') 
    plt.setp(axs2_xlabel_text, size=7, weight='bold', color='black') 
    plt.setp(axs2_ylabel_text, size=7, weight='bold', color='black')
    #设置图例
    didntLike = mlines.Line2D([], [], color='black', marker='.',
                      markersize=6, label='didntLike')
    smallDoses = mlines.Line2D([], [], color='orange', marker='.',
                      markersize=6, label='smallDoses')
    largeDoses = mlines.Line2D([], [], color='red', marker='.',
                      markersize=6, label='largeDoses')
    #添加图例
    axs[0][0].legend(handles=[didntLike,smallDoses,largeDoses])
    axs[0][1].legend(handles=[didntLike,smallDoses,largeDoses])
    axs[1][0].legend(handles=[didntLike,smallDoses,largeDoses])
    #显示图片
    plt.show()
```

##### PYthon知识点：

1)matplotlib的rcParmas、FontProperties

​	I、全局设置

```
#设置字体为SimHei显示中文
plt.rcParams['font.sans-serif'] = 'SimHei'
#设置正常显示字符
plt.rcParams['axes.unicode_minus'] = False
plt.title('sin曲线')
#设置线条样式
plt.rcParams['lines.linestyle'] = '-.'
#设置线条宽度
plt.rcParams['lines.linewidth'] = 3
```

rcParmas是mpl中用于设定默认参数的，包括文字，线条，宽度

​	II、FontProperties用来个性化设置文字样式，有两种方法，一是调用系统，		

​	FontProperties(fname=r"c:\windows\fonts\simsun.ttc", size=14)，具体系统的字体对应名称要进入文件内属	性查看，第二种是直接参数设定，plt.xlabel("横轴/单位",fontproperties="STLiti")，具体样式参数参考[表格]（	http://www.manongjc.com/article/42803.html)

​	III、还可以设置style来保存一套自己的画图模式，直接导出，具体此处不解释，需要再查资料使用

2)plt.subplots

subplots是用来创建画布figure的，常用的参数有，figsize尺寸（nrows,ncols)，facecolor背景色，默认white，num名称，按升序排序,sharex,sharey是否共享坐标轴，nrows=a , ncols= b,分窗口

3）scatter

对点的图像设置，常用的参数有x,y——点的数据来源，s——点的大小，c——点的颜色，marker——点的形状，norm——亮度，alpha——点的透明度，透明度设置的好能够使图好看

4）set_title,set_xlabel,set_ylabel

设置标题(u'   ' )，可以用FontProperties个性化设置样式，前面要用axs[] []指定窗口位置，weight,size,color

5）legend图例

legend自身有很多属性，具体查资料，使用时，可以先定义好各个图例的元素（句柄）的各种属性，包括color，marker,markersize,label(标签)等，通过handles句柄直接添加进去

didntLike = mlines.Line2D([], [], color='black', marker='.',markersize=6, label='didntLike')

axs[0] [0].legend(handles=[didntLike])

6）设置线的属性有三种方式：

​	1、直接在plot设置plt.plot(x, y, linewidth=2.0)

​	2、通过获得线对象，对线对象进行设置

```
line, = plt.plot(x, y, '-')
line.set_antialiased(False) 
```

​	3、使用setp（）函数设置

```
axs2_title_text = axs[1][0].set_title(u'玩视频游戏所消耗时间占比与每周消费的冰激淋公升数',FontProperties=font)
plt.setp(axs2_title_text, size=9, weight='bold', color='red') 
```

7）Line2D

```
matplotlib.lines.Line2D(xdata, ydata, linewidth=None, linestyle=None, color=None, marker=None, markersize=None......)
```

一般作为图例的Line2D的xdata和ydate是[] []

```
didntLike = mlines.Line2D([], [], color='black', marker='.',markersize=6, label='didntLike')
```

##### 3、数据归一化处理（权重处理）

1）如果数据都是等权重的，那么需要对数据进行归一化处理，同样地也可以对不同的数据作不同权重的分配，以下是对等权重的归一化处理。

2）归一化的数学公式为：newValue = (oldValue - min) / (max - min)

```
"""
函数说明:对数据进行归一化
 
Parameters:
    dataSet - 特征矩阵
Returns:
    normDataSet - 归一化后的特征矩阵
    ranges - 数据范围
    minVals - 数据最小值
 
Modify:
    2017-03-24
"""
def autoNorm(dataSet):
    #获得数据的最小值
    minVals = dataSet.min(0)
    maxVals = dataSet.max(0)
    #最大值和最小值的范围
    ranges = maxVals - minVals
    #shape(dataSet)返回dataSet的矩阵行列数
    normDataSet = np.zeros(np.shape(dataSet))
    #返回dataSet的行数
    m = dataSet.shape[0]
    #原始值减去最小值
    normDataSet = dataSet - np.tile(minVals, (m, 1))
    #除以最大和最小值的差,得到归一化数据
    normDataSet = normDataSet / np.tile(ranges, (m, 1))
    #返回归一化数据结果,数据范围,最小值
    return normDataSet, ranges, minVals
```

##### Python知识：

1、min(0)和max(0)，取每一列的最小和最大值，min(1)和max(1)去每一行的最小和最大值，和max()，min()函数不同，和shape[0]和[1]的行列表示相反，()和[]也有区别

2、矩阵的加减需要相同行列才能进行，加减乘除运算后，得到的新矩阵要放入有个相同行列的特征矩阵中，要提前声明特征矩阵，定义行列

##### 4、算法测试

1）算法测试是随机选取数据集的10%数据作为测试，90%作为训练集，分析算法的loss值

```
def datingClassTest():
    #打开的文件名
    filename = "datingTestSet.txt"
    #将返回的特征矩阵和分类向量分别存储到datingDataMat和datingLabels中
    datingDataMat, datingLabels = file2matrix(filename)
    #取所有数据的百分之十
    hoRatio = 0.10
    #数据归一化,返回归一化后的矩阵,数据范围,数据最小值
    normMat, ranges, minVals = autoNorm(datingDataMat)
    #获得normMat的行数
    m = normMat.shape[0]
    #百分之十的测试数据的个数
    numTestVecs = int(m * hoRatio)
    #分类错误计数
    errorCount = 0.0
 
    for i in range(numTestVecs):
        #前numTestVecs个数据作为测试集,后m-numTestVecs个数据作为训练集
        classifierResult = classify0(normMat[i,:], normMat[numTestVecs:m,:],
            datingLabels[numTestVecs:m], 4)
        print("分类结果:%d\t真实类别:%d" % (classifierResult, datingLabels[i]))
        if classifierResult != datingLabels[i]:
            errorCount += 1.0
    print("错误率:%f%%" %(errorCount/float(numTestVecs)*100))
```

##### Python知识点：

1）print()中常用%d,%f,%s

str = "the length of (%s) is %d" %('runoob',len('runoob'))

##### 5、算法使用

1）算法使用要加入input获取数据和交互

2）对获取的数据也需要做相应的归一化处理

```
def classifyPerson():
    resultList = ['讨厌','有些喜欢','非常喜欢']
    precentTag = float(input("玩视频游戏所耗时间百分比:"))
    ffMiles = float(input("每年获得的飞行常客里程数:"))
    iceCream = float(input("每周消费的冰激淋公升数:"))
    filename = "datingTestSet.txt"
    datingDataMat,datingLabels = file2matrix(filename)
    normMat,ranges,minVals = autoNorm(datingDataMat)
    inArr = np.array([ffMiles,precentTag,iceCream])
    normArr = (inArr - minVals)/ranges
    classifierResult = classify0(normArr,datingDataMat,datingLabels,3)
    print("你可能%s这个人" % (resultList[classifierResult-1]))
```

##### Python知识点：

1）resultList[classifierResult-1])由于分类标签集中的数字比显示结果集里的元素索引多1，所以要-1